package controller;

import dao.*;
import model.*;
import util.*;

import java.sql.*;
import java.util.List;

public class DistribuicaoCandidatos {

    private final SalaDAO salaDAO;

    public DistribuicaoCandidatos() {
        this.salaDAO = new SalaDAO();
    }

    public void distribuir(List<Candidato> candidatos) throws SQLException {
        List<Sala> salas = salaDAO.buscarTodas();
        int indexSala = 0;
        int ocupacaoAtual = salaDAO.contarCandidatosNaSala(salas.get(indexSala).getNome());

        Sala salaAtual = salas.get(indexSala);

        for (Candidato candidato : candidatos) {
            if (ocupacaoAtual >= salaAtual.getCapacidade()) {
                indexSala++;
                if (indexSala >= salas.size()) {
                    System.out.println("Não há mais salas disponíveis.");
                    break;
                }
                salaAtual = salas.get(indexSala);
                ocupacaoAtual = salaDAO.contarCandidatosNaSala(salaAtual.getNome());
            }

            inserirNaTabelaSalas(candidato, salaAtual);
            ocupacaoAtual++;
        }

        System.out.println("Distribuição concluída.");
    }

    private void inserirNaTabelaSalas(GerenciarCandidato c, Sala sala) throws SQLException {
        String sql = "INSERT INTO salas (província, nrCandidato, nome, opção1, opção2, disciplina, local, sala) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = Conexao.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, c.getProv_Nasc());
        stmt.setInt(2, c.getId());
        stmt.setString(3, c.getNome());
        stmt.setString(4, c.getOpcao1());
        stmt.setString(5, c.getOpcao2());
        stmt.setString(6, c.getDisciplina());
        stmt.setString(7, c.getLocal());
        stmt.setString(8, sala.getNome());

        stmt.executeUpdate();
        conn.close();
    }
}


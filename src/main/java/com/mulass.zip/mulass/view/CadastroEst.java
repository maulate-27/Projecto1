package view;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.toedter.calendar.JDateChooser;
import dao.*;
import model.*;
import java.util.*;
import java.util.List;
import util.*;
import java.util.Date;
import java.util.Random;
import java.text.*;

public class CadastroEst extends JFrame implements ActionListener {

	private JLabel[] labelP = new JLabel[100];
	private JLabel[] labelC = new JLabel[100];
	private JLabel[] labelI = new JLabel[100];

	private CandidatoDao candao;
	private DisciplinaDao dis;
	private DelegacaoDao deleg;
	private CursoDao cursoDao; 
	private FaculdadeDao facuDao;
	private Menu menu;
	private Login lg = new Login("Maulate");
	
	private JTextField[] textP = new JTextField[100];
	private JTextField[] textI = new JTextField[100];

	private JComboBox<String>[] comboP = new JComboBox[100]; 
	private JComboBox<String>[] comboC = new JComboBox[100];
	private JComboBox<String>[] comboI = new JComboBox[100];
	private JDateChooser dateChooser;

	private JButton[] bt = new JButton[100];
	private Ficheiro fich = new Ficheiro();

	private int Py = 20;
	private JPanel menuPainel;
	private JScrollPane scroll;

	private String[] dadosPessoais = {"Nome","apelido","Sexo","estCivil","Data de Nascimento","Pais","Provincia","Distrito","Bairro"};
	private String[] dados_do_Curso = {"Extensao", "Curso","Regime"};
	private String[] dados_de_ingresso = {"Habilitacao de Ingresso","Provincia","Distrito","Escola","Area de formacao","Ano de Conclusao"};

	public CadastroEst(Menu menu){
		this.menu = menu;
		setTitle("Cadastro de Estudantes");
		setSize(1200,690);
		setDefaultCloseOperation(0);
		setLocationRelativeTo(null);
		
		menuPainel = new JPanel();
		menuPainel.setLayout(null);
		menuPainel.setPreferredSize(new Dimension(750,1000));
		
		scroll = new JScrollPane(menuPainel);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		add(scroll);
		
		this.candao = new  CandidatoDao();
		this.dis = new DisciplinaDao();
		this.deleg = new DelegacaoDao();
		this.cursoDao = new CursoDao();
		this.facuDao = new FaculdadeDao();
		
		DadosP(menuPainel);
		DadosI(menuPainel);
		DadosC(menuPainel);
		butao(menuPainel);
		carregarDadosCombobox();
		setVisible(true);
	}

	public void criarD(){
		dis.criarTabela();
		JOptionPane.showMessageDialog(this,"Tabela candidato criada com sucesso!","Informacao",JOptionPane.INFORMATION_MESSAGE);
	}

	public void criarC(){
		//candao.criarTabela();
		facuDao.criarTabela();
		JOptionPane.showMessageDialog(this,"Tabela candidato criada com sucesso!","Informacao",JOptionPane.INFORMATION_MESSAGE);
	}

	public void DadosC(JPanel fr){

	Py += 50;
	labelC[0] = new JLabel("Dados do Curso");
	labelC[0].setBounds(20,Py,300,20);
	labelC[0].setFont(new Font("Arial",Font.BOLD,20));
	fr.add(labelC[0]);

	//String[] extensoes = {"UPM", "UNIROVUMA", "UNIPUNGUE"};
	//String[] cursos = {"L.Informatica", "Arquitetura", "Gestao Empresariais"};
	//String[] regimes = {"Laboral", "Pos_Laboral", "E.Distancia"};

		for(int i=0; i<dados_do_Curso.length; i++){
			Py += 30;
			labelC[i+1] = new JLabel(dados_do_Curso[i]);
			comboC[i] = new JComboBox<>();
		  comboC[i].setModel(new DefaultComboBoxModel<>());
			
			labelC[i+1].setBounds(20,Py,180,20);
			labelC[i+1].setFont(new Font("Arial", Font.PLAIN, 16));
			comboC[i].setBounds(250,Py,250,25);
			
			fr.add(labelC[i+1]);
			fr.add(comboC[i]);
		}
	}

	public void DadosP(JPanel fr){
		Py = 20;
		labelP[0] = new JLabel("Dados Pessoais");
		labelP[0].setBounds(20,Py,300,20);
		labelP[0].setFont(new Font("Arial", Font.BOLD, 20)); 
		fr.add(labelP[0]);
			
		String[] sexos = {"M", "F"};
		String[] estCivil = {"S","C","D","V"};
			
		for(int i=0; i<dadosPessoais.length; i++){
			Py+=30;
			labelP[i+1] = new JLabel(dadosPessoais[i]);
			labelP[i+1].setBounds(20,Py,180,20); 
			
			if(dadosPessoais[i].equals("Sexo") || dadosPessoais[i].equals("Provincia") || dadosPessoais[i].equals("estCivil")){
			comboP[i] = new JComboBox<>();
				if(dadosPessoais[i].equals("Sexo")){
				 comboP[i].setModel(new DefaultComboBoxModel<>(sexos));
				 
				}else if(dadosPessoais[i].equals("Provincia")){
					comboP[i].setModel(new DefaultComboBoxModel<>());
					
				}else if(dadosPessoais[i].equals("estCivil")){
					comboP[i].setModel(new DefaultComboBoxModel<>(estCivil));
					
				}
				comboP[i].setBounds(250,Py,250,25);
				fr.add(comboP[i]);
					
				}else if(dadosPessoais[i].equals("Data de Nascimento")){
					dateChooser = new JDateChooser();
		    	dateChooser.setBounds(250, Py, 250, 25);
		    	fr.add(dateChooser);
				}else{
					textP[i] = new JTextField(20);
					textP[i].setBounds(250,Py,250,25);
					fr.add(textP[i]);
				}
			
				fr.add(labelP[i+1]);
		}
	}

	public void DadosI(JPanel fr){
		Py += 50;
		labelI[0] = new JLabel("Dados de Igresso");
		labelI[0].setBounds(20,Py,300,20);
		labelI[0].setFont(new Font("Arial", Font.BOLD, 20)); 
		fr.add(labelI[0]);	
		
		String[] habilitacoes = {"Medio", "Superior", "Mestrado"};
		String[] areas = {"GrupoC", "GrupoA", "GrupoB"};
		String[] distritos = {"MAssaca","Boane","Goba","Fomento","Boquisso","Matola","Nhangau","Namaroi"};
		
		for(int i=0; i<dados_de_ingresso.length; i++){
			Py+=30;
			labelI[i+1] = new JLabel(dados_de_ingresso[i]);
			labelI[i + 1].setBounds(20, Py, 180, 20);
			
			if(dados_de_ingresso[i].equals("Habilitacao de Ingresso") || dados_de_ingresso[i].equals("Area de formacao") || dados_de_ingresso[i].equals("Provincia") || dados_de_ingresso[i].equals("Escola") || dados_de_ingresso[i].equals("Distrito")){
				comboI[i] = new JComboBox<>();

		    if (dados_de_ingresso[i].equals("Habilitacao de Ingresso")) {
			    comboI[i].setModel(new DefaultComboBoxModel<>(habilitacoes));
		    }else if(dados_de_ingresso[i].equals("Provincia")){
		    	comboI[i].setModel(new DefaultComboBoxModel<>());
		    }else if(dados_de_ingresso[i].equals("Distrito")){
		    	comboI[i].setModel(new DefaultComboBoxModel<>(distritos));
		    }else if(dados_de_ingresso[i].equals("Escola")){
		    	comboI[i].setModel(new DefaultComboBoxModel<>());
		    }else{
		     	comboI[i].setModel(new DefaultComboBoxModel<>(areas));
		    }

		    comboI[i].setBounds(250, Py, 250, 25);
		    fr.add(comboI[i]);
		    
				}else{
					textI[i] = new JTextField(20);
					textI[i].setBounds(250,Py,250,25);
					fr.add(textI[i]);
				}
		
				fr.add(labelI[i+1]);	
		}
	}

	public void butao(JPanel fr){
		try{
			Py += 50; 
			bt[0] = new JButton("Salvar");
			bt[1] = new JButton("Sair");
			//bt[2] = new JButton("Carregar");
			
			bt[0].setBounds(50,Py,150,20);
			bt[1].setBounds(220,Py,150,20);
			//bt[2].setBounds(390,Py,150,20);
			
			fr.add(bt[0]);
			fr.add(bt[1]);
			//fr.add(bt[2]);
			
			bt[0].addActionListener(this);
			bt[1].addActionListener(this);
			//bt[2].addActionListener(this);
			
		}catch(Exception e){
		lg.Som();
			JOptionPane.showMessageDialog(this,"Houve algum erro","Erro",JOptionPane.ERROR_MESSAGE);
		}
	}

	private Date parseDate(String  dateString){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			return sdf.parse(dateString);
		}catch(ParseException eq){
		lg.Som();
			JOptionPane.showMessageDialog(this,"Formato de data invalido!!","Erro", JOptionPane.ERROR_MESSAGE);
			throw new RuntimeException("Erro ao converter data",eq);
		}
	}

	public void cadastrar(){
		
		if(!validarCampo()){
		lg.Som();
				JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios!", "Erro", JOptionPane.ERROR_MESSAGE);
			  return;
			}	
		
	 	JDialog progressDialog = new JDialog(this, "Processando", true);
    JProgressBar progressBar = new JProgressBar();
    progressBar.setIndeterminate(true);
    progressDialog.add(progressBar);
    progressDialog.setSize(300, 75);
    progressDialog.setLocationRelativeTo(this);
	
	
	
	new Thread(() -> {
	
	Random rm = new Random();
	int nrCandidato = 1000 + rm.nextInt(9000);
		try{
		
				Thread.sleep(1500);
			
			String nome = textP[0].getText().trim(); // Assumindo que o primeiro campo é o nome
			String apelido = textP[1].getText().trim();
			String sexo = comboP[2].getSelectedItem().toString(); // Assumindo que o segundo campo é sexo
			String estCivil = comboP[3].getSelectedItem().toString();
			String dataNasc = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
			String pais = textP[5].getText().trim(); // Assumindo que o quarto campo é país
			String provincia = comboP[6].getSelectedItem().toString(); // Assumindo que o quinto campo é província
			String distrito = textP[7].getText().trim(); // Assumindo que o sexto campo é distrito
			String bairro = textP[8].getText().trim(); // Assumindo que o sétimo campo é bairro

			// Coletar dados de curso
			String extensao = comboC[0].getSelectedItem().toString(); // Extensão
			String curso = comboC[1].getSelectedItem().toString(); // Curso
			String regime = comboC[2].getSelectedItem().toString(); // Regime

			// Coletar dados de ingresso
			String habilitacao = comboI[0].getSelectedItem().toString(); // Habilitação
			String provinciaEscola = comboI[1].getSelectedItem().toString(); // Província da escola
			String distritoEscola = comboI[2].getSelectedItem().toString(); // Distrito da escola
			String escola = comboI[3].getSelectedItem().toString(); // Escola
			String areaFormacao = comboI[4].getSelectedItem().toString(); // Área de formação
			String anoConclusao = textI[5].getText().trim(); // Ano de conclusão

		
			GerenciarCandidato candidato = new GerenciarCandidato();
			candidato.setNome(nome);
			candidato.setApelido(apelido);
			candidato.setNrCandidato(nrCandidato);
			candidato.setGenero(sexo.substring(0, 1));
			candidato.setPais(pais);
			candidato.setProv_Nasc(provincia);
			candidato.setProv_Resi(provincia); 
			candidato.setNacionalidade("Mocambicana");
			candidato.setEstCivil(estCivil);
			candidato.setData_nasc(parseDate(dataNasc));
			candidato.setRegime(regime);
			candidato.setDelegacao(extensao);
			candidato.setEscoPU(escola);
			candidato.setOpcao1(curso);
			candidato.setOpcao2(curso);
			candidato.setTipoEst(habilitacao);
			
			candao.salvar(candidato);
			
			 SwingUtilities.invokeLater(() -> {
			 					 
                progressDialog.dispose();
                JOptionPane.showMessageDialog(this, "Candidato " + candidato.getNome() + 
                                           " gravado com sucesso!!", "Informação", 
                                           JOptionPane.INFORMATION_MESSAGE);
                limparCampos();
            });
		}catch(Exception et){
		
		 SwingUtilities.invokeLater(() -> {
		 
      	progressDialog.dispose();
      	JOptionPane.showMessageDialog(this, "Houve um erro inesperado " + et, "Erro", JOptionPane.ERROR_MESSAGE);
     });
		}
	}).start();
	progressDialog.setVisible(true);
	}

	private boolean validarCampo(){
		for (int i = 0; i < dadosPessoais.length; i++) {
			if (dadosPessoais[i].equals("Data de Nascimento")) {
		  	if (((JTextField) dateChooser.getDateEditor().getUiComponent()).getText().trim().isEmpty()) {
		    	return false;
		    }
		  }else if(dadosPessoais[i].equals("Provincia")){
		  	if(comboP[i].getSelectedItem() == null) {
		  		return false;
		  	}
		  }else if (dadosPessoais[i].equals("Sexo")) {
		  	if (comboP[i].getSelectedItem() == null) {
		    	return false;
		    }
		  }else if(dadosPessoais[i].equals("estCivil")){
		  	if(comboP[i].getSelectedItem()==null){
		    	return false;
		   	}
		  }else if (textP[i].getText().trim().isEmpty()) {
		  	return false;
		  }
		}

	 	for (int i = 0; i < dados_do_Curso.length; i++) {
			if (comboC[i].getSelectedItem() == null) {
		  	return false;
		  }
		}

		for (int i = 0; i < dados_de_ingresso.length; i++) {
			
			if(dados_de_ingresso[i].equals("Provincia")){
				if(comboI[i].getSelectedItem() == null){
					return false;
				}
			}else if(dados_de_ingresso[i].equals("Distrito")){
				if(comboI[i].getSelectedItem() == null){
					return false;
				}
			}else if(dados_de_ingresso[i].equals("Area de formacao")){
				if(comboI[i].getSelectedItem() == null){
					return false;
				}
			 }else if(dados_de_ingresso[i].equals("Habilitacao de Ingresso")){
				if(comboI[i].getSelectedItem() == null){
					return false;
				}
			} else if(dados_de_ingresso[i].equals("Escola")){
				if(comboI[i].getSelectedItem() == null){
					return false;
				}
			}else if(textI[i].getText().trim().isEmpty()) {
		  	return false;
			}
		}
		return true;
	}
		
	private void carregarDadosCombobox() {
		try{
	 		//Busca os dados do banco
		   List<String> extensoes = cursoDao.buscarExtensoes();
		   List<String> cursos = cursoDao.buscarCursos();
		   List<String> regimes = cursoDao.buscarRegimes();
		   List<String> provin = cursoDao.buscarProvincia();
		   List<String> escola = cursoDao.buscarEscola();
		        
		   // Atualiza os combobox
		   atualizarComboboxExtensoes(extensoes);
		   atualizarComboboxCursos(cursos);
		   atualizarComboboxRegimes(regimes);
		   actualizarProvincia(provin);
		   actualizarEscola(escola);
		        
		}catch(SQLException e) {
		lg.Som();
			JOptionPane.showMessageDialog(this, "Erro ao carregar dados: " + e.getMessage(),  "Erro", JOptionPane.ERROR_MESSAGE);
		  e.printStackTrace();
		}
	}
	
	private void actualizarEscola(List<String> escolas){
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
		for(String escola : escolas){
			model.addElement(escola);
		}
		
		for(int i = 0; i< dados_de_ingresso.length; i++){
			if(dados_de_ingresso[i].equals("Escola") && comboI[i] != null){
				comboI[i].setModel(model);
				break;
			}
		}
	}
	
	private void actualizarProvincia(List<String> provincia){
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
		for(String prov : provincia){
			model.addElement(prov);
		}
		
		for(int i = 0; i< dadosPessoais.length; i++){
			if(dadosPessoais[i].equals("Provincia") && comboP[i] != null) {
			System.out.println("Existe ligacao aqui!");
				comboP[i].setModel(model);
				break;
			} 
		}
		
		for(int i = 0; i<dados_de_ingresso.length; i++){
			if(dados_de_ingresso[i].equals("Provincia") && comboI[i] != null){
				comboI[i].setModel(model);
				break;
			}
		}
	}
		
	private void atualizarComboboxExtensoes(List<String> extensoes) {
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
		for(String extensao : extensoes) {
			model.addElement(extensao);
		}
		    
		// Encontra o combobox de extensão e atualiza
		for (int i = 0; i < dados_do_Curso.length; i++) {
			if (dados_do_Curso[i].equals("Extensao") && comboC[i] != null) {
		  	comboC[i].setModel(model);
		    break;
		  }
		}
	}
		
	private void atualizarComboboxCursos(List<String> cursos) {
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
			for(String curso : cursos){
		  	model.addElement(curso);
		  }
		    
		  // Encontra o combobox de curso e atualiza
		  for(int i = 0; i < dados_do_Curso.length; i++){
		  	if (dados_do_Curso[i].equals("Curso") && comboC[i] != null) {
		    	comboC[i].setModel(model);
		      break;
		    }
		  }
		}
		
		private void atualizarComboboxRegimes(List<String> regimes) {
			DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
		  for(String regime : regimes){
		  	model.addElement(regime);
		  }
		    
		  // Encontra o combobox de regime e atualiza
		  for (int i = 0; i < dados_do_Curso.length; i++) {
		  	if (dados_do_Curso[i].equals("Regime") && comboC[i] != null) {
		    	comboC[i].setModel(model);
		      break;
		    }
		  }
		}
		
		public void limparCampos(){
			textP[0].setText("");
			textP[1].setText(""); // Assumindo que o primeiro campo é o nome
		  comboP[2].setSelectedItem(""); // Assumindo que o segundo campo é sexo
		  comboP[3].setSelectedItem("");
		  ((JTextField) dateChooser.getDateEditor().getUiComponent()).setText("");
		  textP[5].setText(""); // Assumindo que o quarto campo é país
		  comboP[6].setSelectedItem(""); // Assumindo que o quinto campo é província
		  textP[7].setText(""); // Assumindo que o sexto campo é distrito
		  textP[8].setText(""); // Assumindo que o sétimo campo é bairro
		  comboC[0].setSelectedItem(""); // Extensão
		  comboC[1].setSelectedItem(""); // Curso
		  comboC[2].setSelectedItem(""); // Regime
		  comboI[0].setSelectedItem(""); // Habilitação
		  comboI[1].setSelectedItem(""); // Província da escola
		  comboI[2].setSelectedItem(""); // Distrito da escola
		  comboI[3].setSelectedItem(""); // Escola
		  comboI[4].setSelectedItem(""); // Área de formação
		  textI[5].setText(""); // Ano de conclusão
		}
		
		public void actionPerformed(ActionEvent e){
			
			if(e.getSource() == bt[0]){
				cadastrar();
			}else if(e.getSource() == bt[1]){
				dispose();
				menu.setVisible(true);
			}
		}
}

package view;

import java.awt.*;
import java.sql.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;
import model.*;
import Jogo.*;
import util.*;
import dao.*;
import controller.*;
import javax.swing.table.*;

public class Menu extends JFrame implements ActionListener {
	
	private JMenuBar menubar = new JMenuBar();
	private JPanel pane;
	private JPanel pane2;
	private CardLayout cardLayout;
	public final Conexao conm = new Conexao();
	//Connection conexion = conm.getConnection();
	
	private JList list;
	private DefaultListModel<String> listmodel;	
	private DefaultTableModel tablemodel;
	private JTable tabela;
	
	private JTextArea area;
	private JScrollPane scroll;
	private CadastroEst cad;
	private CursoDao curso = new CursoDao();
	private Maulate jogo;
	private JButton bt;
	private Login lg;
	private RelatorioPDF pdf = new RelatorioPDF();
	private CandidatoDao dt = new CandidatoDao();
	private String	dados;
	private JMenuItem[] itens = new JMenuItem[100];
	private JMenu[] menu = new JMenu[100];
	private String exameR = "RelaExame";
	private String[] word = {"Candidato","Relatorios","Sobre","Sair","Cadastrar","Visualizar","Buscar", "Jogo","TabelasBasicas"};
	private String[] colunas = {"ID","Nome","Apelido","Data_Nasc","Genero","EstadoCivil","Nacionalidade","Prov_Nasc","Prov_Resi","Delegacao","EscPU","Opcao1","Opcao2","TipoEst"};
	private String[] colunasC = {"Sequencia","Codigo","Activo","Descricao","Regime_id","Faculdade","CodigoGerado"};
	
	private String[] tabelasBasicas = {
																		"curso",      
																		"delegacao",  
																		"disciplinas",
																		"escolapreu",
																		"faculdade",  
																		"grupos",    
																		"localidade", 
																		"regime", 
																		"salas"
																	};      

	
	public Menu(Login lg){
	this.lg= lg;
		setTitle("Tela Menu Administrador");
		setSize(400,300);
		setDefaultCloseOperation(0);
		setLocationRelativeTo(null);
		setLayout(null);
		
		
		menu[0] = new JMenu(word[0]);
		menu[1] = new JMenu(word[1]);
		menu[2] = new JMenu(word[2]);
		
		
		itens[0] = new JMenuItem(word[3]);
		itens[4] = new JMenuItem(word[7]);
		
		itens[1] = new JMenuItem(word[4]);
		itens[2] = new JMenuItem(word[5]);
		itens[3] = new JMenuItem(word[6]);
		
		menu[0].add(itens[1]);
		//menu[0].add(itens[2]);
		menu[0].add(itens[3]);
		
		menubar.add(menu[0]);
		menubar.add(menu[1]);
		menubar.add(menu[2]);
		menubar.add(itens[0]);
		menubar.add(itens[4]);
		
		setJMenuBar(menubar);
		itens[0].addActionListener(this);
		itens[1].addActionListener(this);
		itens[4].addActionListener(this);
		setVisible(true);
	}
	
	public Menu(Login lf, String nam){
		this.lg= lf;
		setTitle("Tela Menu Gestor");
		setSize(1500,1000);
		setDefaultCloseOperation(0);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		//setLayout(null);
		
		
		pane = new JPanel();
		pane.setLayout(new BorderLayout());
		pane.setPreferredSize(new Dimension(200,300));
		
		cardLayout = new CardLayout();
		pane2 = new JPanel(cardLayout);
		//pane2.setLayout(new BorderLayout());
		//pane2.setPreferredSize(new Dimension(200,300));
		
		menu[0] = new JMenu(word[0]);
		menu[1] = new JMenu(word[1]);
		menu[2] = new JMenu(word[2]);
		menu[3] = new JMenu(word[8]);
		
		itens[0] = new JMenuItem(word[3]);
		itens[4] = new JMenuItem(word[7]);
		
		for(int i=0;i<tabelasBasicas.length;i++){
			itens[i+5] = new JMenuItem(tabelasBasicas[i]);
			menu[3].add(itens[i+5]);
				/*itens[6] = new JMenuItem(tabelasBasicas[1]);
				itens[7] = new JMenuItem(tabelasBasicas[2]);
				itens[8] = new JMenuItem(tabelasBasicas[3]);
				itens[9] = new JMenuItem(tabelasBasicas[4]);*/
	}
		
		
		
		//itens[1] = new JMenuItem(word[4]);
		itens[2] = new JMenuItem(word[5]);
		itens[3] = new JMenuItem(word[6]);
		itens[15] = new JMenuItem(exameR);
		menu[1].add(itens[15]);
		
		
		//menu[0].add(itens[1]);
		menu[0].add(itens[2]);
		menu[0].add(itens[3]);
		//menu[3].add(itens[5]);
		//menu[3].add(itens[6]);
		//menu[3].add(itens[7]);
		//menu[3].add(itens[8]);
		//menu[3].add(itens[9]);
		
		
		menubar.add(menu[0]);
		menubar.add(menu[1]);
		menubar.add(menu[2]);
		menubar.add(menu[3]);
		menubar.add(itens[0]);
		menubar.add(itens[4]);
		
		pane.add(menubar);
		add(pane2,BorderLayout.CENTER);
		setJMenuBar(menubar);
		//Area(this);
		itens[0].addActionListener(this);
		itens[2].addActionListener(this);
		itens[4].addActionListener(this);
		itens[5].addActionListener(this);
		itens[15].addActionListener(this);
		setVisible(true);
	}
	
	public void close(JFrame ft){
		ft.setVisible(false);
	}
	
	public void open(JFrame ft){
		ft.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		try{
			if(e.getSource() == itens[0]){
				dispose();
				lg.setVisible(true);
			}else if(e.getSource() == itens[15]){
			String caminho = "/home/maulate/Transferências/Projecto1/src/main/java/com/Relatorio.pdf";
				pdf.gerarRelatorio(caminho);
				RelatorioPDF.abrirPDF(caminho);
			}else if(e.getSource()== itens[1]){
				cad = new CadastroEst(this);
				
				try{
					Connection cone = conm.getConnection();
					JOptionPane.showMessageDialog(this,"Conectado a base de Dados!!","Informacao",JOptionPane.INFORMATION_MESSAGE);
					close(this);
	//				PreparedStatement stmt = cone.prepareStatement(s
				}catch(Exception eq){
					JOptionPane.showMessageDialog(this,"Qualquer erro!!","Erro!!",JOptionPane.ERROR_MESSAGE);
				}
			}else if(e.getSource()== itens[2]){
				/*area = new JTextArea(getWidth(),getHeight());
				scroll = new JScrollPane(area);
		
				scroll.setBounds(0,0,getWidth(),getHeight()-30);
				area.setText(CadastroEst.dados);
				this.add(scroll);*/
				 //Ficheiro fich = new Ficheiro();
        // ArrayList<String> dados = fich.ler();
        // listmodel = new DefaultListModel<>();
        // list = new JList(listmodel);
         //String[] linhas = dados.split("\n");

                // Criar tabela
       
                tablemodel = new DefaultTableModel(colunas, 0);
              	tabela = new JTable(tablemodel);
              	
                JScrollPane scroll = new JScrollPane(tabela);
              // 	scroll.setBounds(0, 0, getWidth(), getHeight() - 30);
               	//scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
								//scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
               	//pane2.removeAll();
     						pane2.add(scroll,"candidato");	
        				//pane2.revalidate();
       					
             		actualizarTable();
             		cardLayout.show(pane2, "candidato");
             	//	pane2.repaint();

					
			}else if(e.getSource()== itens[3]){
			
			}else if(e.getSource() == itens[4]){
				jogo =  new Maulate();
			}else if(e.getSource() == itens[5]){
				tablemodel = new DefaultTableModel(colunasC, 0);
        tabela = new JTable(tablemodel);
              	
        JScrollPane scroll = new JScrollPane(tabela);
        // 	scroll.setBounds(0, 0, getWidth(), getHeight() - 30);
       // scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				//	scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
				//this.removeAll();
        //pane2.removeAll();
     		pane2.add(scroll,"curso");	
        //pane2.revalidate();
       	//pane2.repaint();
				CursoF();
				
				cardLayout.show(pane2, "curso");
				//pane2.repaint();
			}
			conm.fechar();
		}catch(Exception ep){
			lg.Som();
			JOptionPane.showMessageDialog(this,"Menu error!! " + ep , "Error", JOptionPane.ERROR_MESSAGE);
			conm.fechar();
		}
	}
	
	public void actualizar(){
		listmodel.clear();
		
		try{
		List<String> dados = dt.buscar();
		for(String item : dados){
		 listmodel.addElement(item);
		}
		}catch(SQLException e){
		lg.Som();
			throw new RuntimeException("Ocorreu um erro!!" + e);
		}
	}
	
	public void CursoF(){
		tablemodel.setRowCount(0);
		try{
			List<String> dados = curso.buscarCursos("Completo");
			for(String var: dados){
				if(!var.trim().isEmpty()){
					String[] valores = var.split(",");
					if(valores.length == colunasC.length){
						tablemodel.addRow(valores);
					}
				}
			}
		}catch(SQLException e){
		lg.Som();
			throw new RuntimeException("Ocorreu um erro!! " + e);
		}
	}
	
	public void actualizarTable(){
	tablemodel.setRowCount(0);
	try{
		List<String> dados = dt.buscar();
		for(String var: dados){
      if(!var.trim().isEmpty()){
         String[] valores = var.split(",");
         if(valores.length == colunas.length){
            tablemodel.addRow(valores);
         }
      }
 		}
 	}catch(SQLException e){
 	lg.Som();
 		throw new RuntimeException("Ocorreu um erro!!" + e);
 	}
	}
}

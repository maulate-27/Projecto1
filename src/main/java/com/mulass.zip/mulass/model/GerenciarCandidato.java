package model;

import java.io.*;
import java.util.Date;

public  class GerenciarCandidato {

		private int id;
    private String nome;
    private String apelido;
    private int nrCandidato;
    private String genero;
    private String pais;
    private String prov_Nasc;
    private String prov_Resi;
    private String nacionalidade;
    private String estCivil;
    private Date data_nasc;
    private String regime;
    private String delegacao;
    private String escoPU;
    private String opcao1;
    private String opcao2;
    private String tipoEst;
    
    public GerenciarCandidato(){}
    public GerenciarCandidato(
    	int id, String nome, String apelido, int nrCandidato, String genero, String pais, String prov_Nasc, String prov_Resi, String nacionalidade, String estCivil, Date data_nasc, String regime, String delegacao, String escoPU, String opcao1, String opcao2, String tipoEst
    ){
    	this.id = id;
    	this.nome = nome;
    	this.apelido = apelido;
    	this.nrCandidato = nrCandidato;
    	this.genero = genero;
    	this.pais = pais;
    	this.prov_Nasc = prov_Nasc;
    	this.prov_Resi = prov_Resi;
    	this.nacionalidade = nacionalidade;
    	this.estCivil = estCivil;
    	this.data_nasc = data_nasc;
    	this.regime = regime;
    	this.delegacao = delegacao;
    	this.escoPU = escoPU;
    	this.opcao1 = opcao1;
    	this.opcao2 = opcao2;
    	this.tipoEst = tipoEst;
    	
    }
    
    public void setId(int id){
    	this.id = id;
    }
    
    public int getId(){
    	return id;
    }
    
    public void setNome(String nome){
    	this.nome = nome;
    }
    
    public String getNome(){
    	return nome;
    }
    
    public void setApelido(String apelido){
    	this.apelido = apelido;
    }
    
    public String getApelido(){
    	return apelido;
    }
    
    public void setNrCandidato(int nrCandidato){
    	this.nrCandidato = nrCandidato;
    }
    
    public int getNrCandidato(){
    	return nrCandidato;
    }
    
    public void setGenero(String genero){
    	this.genero = genero;
    }
    
    public String getGenero(){
    	return genero;
    }
    
    public void setPais(String pais){
    	this.pais = pais;
    }
    
    public String getPais(){
    	return pais;
    }
    
    public void setProv_Nasc(String prov_Nasc){
    	this.prov_Nasc = prov_Nasc;
    }
    
    public String getProv_Nasc(){
    	return prov_Nasc;
    }
    
    public void setProv_Resi(String prov_Resi){
    	this.prov_Resi = prov_Resi;
    }
    
    public String getProv_Resi(){
    	return prov_Resi;
    }
    
    public void setNacionalidade(String nacionalidade){
    	this.nacionalidade = nacionalidade;
    }
    
    public String getNacionalidade(){
    	return nacionalidade;
    }
    
    public void setEstCivil(String estCivil){
    	this.estCivil = estCivil;
    }
    
    public String getEstCivil(){
    	return estCivil;
    }
    
    public void setData_nasc(Date data_nasc){
    	this.data_nasc = data_nasc;
    }
    
    public Date getData_nasc(){
    	return data_nasc;
    }
    
    public void setRegime(String regime){
    	this.regime = regime;
    }
    
    public String getRegime(){
    	return regime;
    }
    
    public void setDelegacao(String delegacao){
    	this.delegacao = delegacao;
    }
    
    public String getDelegacao(){
    	return delegacao;
    }
    
    public void setEscoPU(String escoPU){
    	this.escoPU = escoPU;
    }
    
    public String getEscoPU(){
    	return escoPU;
    }
    
    public void setOpcao1(String opcao1){
    	this.opcao1 = opcao1;
    }
    
    public String getOpcao1(){
    	return opcao1;
    }
    
    public void setOpcao2(String opcao2){
    	this.opcao2 = opcao2;
    }
    
    public String getOpcao2(){
    	return opcao2;
    }
    
    public void setTipoEst(String tipoEst){
    	this.tipoEst = tipoEst;
    }
    
    public String getTipoEst(){
    	return tipoEst;
    }
       
    public String  Dados(){
    	return nome + " " + apelido + " " + opcao1;
    }
}

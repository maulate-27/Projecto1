package model;

import java.util.*;

public class  Disciplina {
	private int id;
	private int codDisc;
	private String designacao;
	private Date data;
	private Date hora;
	private Date horaEntrada;
	private int ord;
	private String subj;
	
	public Disciplina(int id, int codDisc, String designacao, Date data, Date hora, Date horaEntrada, int ord, String subj){
	
		this.id = id;
		this.codDisc = codDisc;
		this.designacao = designacao;
		this.data = data;
		this.hora = hora;
		this.horaEntrada = horaEntrada;
		this.ord = ord;
		this.subj = subj;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
	
	public void setCodDisc(int codDisc){
		this.codDisc = codDisc;
	}
	
	public int getCodDisc(){
		return codDisc;
	}
	
	public void setDesignacao(String designacao){
		this.designacao = designacao;
	}
	
	public String getDesignacao(){
		return designacao;
	}
	
	public void setData(Date data){
		this.data = data;
	}
	
	public Date getData(){
		return data;
	}
	
	public void setHora(Date hora){
		this.hora = hora;
	}
	
	public Date getHora(){
		return hora;
	}
	
	public void setHoraEntrada(Date horaEntrada){
		this.horaEntrada = horaEntrada;
	}
	
	public Date getHoraEntrada(Date horaEntrada){
		return horaEntrada;
	}
	
	public void setOrd(int ord){
		this.ord = ord;
	}
	
	public int getOrd(){
		return ord;
	}
	
	public void setSubj(String subj){
		this.subj = subj;
	}
	
	public String getSubj(){
		return subj;
	}
}

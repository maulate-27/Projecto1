import view.*;

class Admisao{
	public static void main(String[] ar){
		new Login();
	}
}

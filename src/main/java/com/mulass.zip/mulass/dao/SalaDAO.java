package dao;

import  java.sql.*;

public class SalaDAO {
	
}

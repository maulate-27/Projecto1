package dao;

import model.*;
import util.*;
import java.sql.*;


public class DisciplinaDao {
	
	public void criarTabela(){
		String sql = "CREATE TABLE IF NOT EXISTS disciplinas("+
				"id INT GENERATED ALWAYS AS IDENTITY," +
				"codDisc INT," +
				"designacao VARCHAR(100)," +
				"data DATE,"+
				"hora VARCHAR(10),"+
				"horaEntrada VARCHAR(10),"+
				"ord INT,"+
				"subj VARCHAR(10)," +
				"CONSTRAINT PK_disc PRIMARY KEY(id,codDisc)"+
				")";
				
			try(Connection con = Conexao.getConnection();
				Statement stm = con.createStatement()){
				stm.executeUpdate(sql);
			}catch(SQLException e){
				throw new RuntimeException("Qualquer erro");
			}
	}
	
	public void salvar(Disciplina disc){
		
	}
}

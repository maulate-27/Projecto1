package dao;

import model.*;
import util.*;
import java.sql.*;

public class FaculdadeDao{
	public final Conexao conm = new Conexao();

	public void criarTabela(){
		String sql = "CREATE TABLE IF NOT EXISTS faculdade("+
									"cod serial," +
									"designacao VARCHAR(100)," +
									"abrev VARCHAR(100),"+
									"CONSTRAINT pk_facul PRIMARY KEY(cod)"+
									")";
	
		try(Connection conex = conm.getConnection();
			Statement stmt = conex.createStatement()){
				stmt.executeUpdate(sql);
				conm.fechar();
		}catch(SQLException e){
			conm.fechar();
			throw new RuntimeException("Houve qualquer erro");
		}
	}
}
